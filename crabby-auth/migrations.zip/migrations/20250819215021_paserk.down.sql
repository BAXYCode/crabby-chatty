-- Add down migration script here
DROP TABLE if EXISTS valid.keypairs;
